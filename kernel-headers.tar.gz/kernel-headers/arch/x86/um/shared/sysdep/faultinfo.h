#ifdef __i386__
#include "faultinfo_32.h"
#else
#include "faultinfo_64.h"
#endif
