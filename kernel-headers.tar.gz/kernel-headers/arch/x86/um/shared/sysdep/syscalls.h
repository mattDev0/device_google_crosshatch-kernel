#ifdef __i386__
#include "syscalls_32.h"
#else
#include "syscalls_64.h"
#endif
