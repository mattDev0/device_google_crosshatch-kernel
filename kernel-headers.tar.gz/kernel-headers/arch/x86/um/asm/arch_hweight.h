#ifndef _ASM_UM_HWEIGHT_H
#define _ASM_UM_HWEIGHT_H

#include <asm-generic/bitops/arch_hweight.h>

#endif
