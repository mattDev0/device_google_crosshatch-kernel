/* 
 * Copyright (C) 2002 Jeff Dike (jdike@karaya.com)
 * Licensed under the GPL
 */

#ifndef __UM_IRQ_VECTORS_H
#define __UM_IRQ_VECTORS_H

#endif

