#ifndef __UM_REQUIRED_FEATURES_H
#define __UM_REQUIRED_FEATURES_H

/*
 * Nothing to see, just need something for the i386 and x86_64 asm
 * headers to include.
 */

#endif
