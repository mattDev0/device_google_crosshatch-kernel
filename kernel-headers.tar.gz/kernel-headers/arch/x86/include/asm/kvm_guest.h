#ifndef _ASM_X86_KVM_GUEST_H
#define _ASM_X86_KVM_GUEST_H

int kvm_setup_vsyscall_timeinfo(void);

#endif /* _ASM_X86_KVM_GUEST_H */
