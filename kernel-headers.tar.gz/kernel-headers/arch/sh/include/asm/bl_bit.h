#ifndef __ASM_SH_BL_BIT_H
#define __ASM_SH_BL_BIT_H

#ifdef CONFIG_SUPERH32
# include <asm/bl_bit_32.h>
#else
# include <asm/bl_bit_64.h>
#endif

#endif /* __ASM_SH_BL_BIT_H */
