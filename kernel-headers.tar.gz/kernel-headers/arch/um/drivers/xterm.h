/* 
 * Copyright (C) 2002 Jeff Dike (jdike@karaya.com)
 * Licensed under the GPL
 */

#ifndef __XTERM_H__
#define __XTERM_H__

extern int xterm_fd(int socket, int *pid_out);

#endif

