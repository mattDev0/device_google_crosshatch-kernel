#ifndef __UM_SECTIONS_H
#define __UM_SECTIONS_H

#include <asm-generic/sections.h>

extern char __binary_start[];
extern char __syscall_stub_start[], __syscall_stub_end[];

#endif
