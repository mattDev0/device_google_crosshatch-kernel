/* 
 * Copyright (C) 2002 Jeff Dike (jdike@karaya.com)
 * Licensed under the GPL
 */

#ifndef __UM_KMAP_TYPES_H
#define __UM_KMAP_TYPES_H

/* No more #include "asm/arch/kmap_types.h" ! */

#define KM_TYPE_NR 14

#endif
